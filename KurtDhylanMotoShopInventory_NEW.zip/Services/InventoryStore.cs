using System.Text.Json;
using KurtDhylanMotoShopInventory.Models;
namespace KurtDhylanMotoShopInventory.Services;
public static class InventoryStore
{
    static string ProductFile => Path.Combine(FileSystem.AppDataDirectory, "products.json");
    static string ServiceFile => Path.Combine(FileSystem.AppDataDirectory, "services.json");

    public static async Task<List<InventoryItem>> LoadProducts()
        => await Load<InventoryItem>(ProductFile);
    public static async Task<List<ServiceItem>> LoadServices()
        => await Load<ServiceItem>(ServiceFile);

    public static async Task SaveProducts(List<InventoryItem> items)
        => await Save(ProductFile, items);
    public static async Task SaveServices(List<ServiceItem> items)
        => await Save(ServiceFile, items);

    static async Task<List<T>> Load<T>(string path)
    {
        if (!File.Exists(path)) return new List<T>();
        try { return JsonSerializer.Deserialize<List<T>>(await File.ReadAllTextAsync(path)) ?? new(); }
        catch { return new(); }
    }
    static async Task Save<T>(string path, List<T> items)
        => await File.WriteAllTextAsync(path, JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true }));
}
